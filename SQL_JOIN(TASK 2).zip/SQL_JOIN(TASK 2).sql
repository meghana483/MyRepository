
CREATE DATABASE  USER_DATABASE_db;

Use USER_DATABASE_db;

CREATE TABLE USER_TABLE (
    id SERIAL PRIMARY KEY,
    username VARCHAR(25),
	name VARCHAR(255)
);     



SELECT * FROM USER_TABLE;


INSERT INTO USER_TABLE (id, username, name)
VALUES (1, 'user1','John Doe');

INSERT INTO USER_TABLE (id, username, name)
VALUES (2, 'user2','Jane Smith');

INSERT INTO USER_TABLE (id, username, name)
VALUES (3, 'user3','Bob Johnson');


CREATE TABLE posts  (
    post_id SERIAL PRIMARY KEY,
    title VARCHAR(25),
	content VARCHAR(255)
);     

DROP TABLE posts;

INSERT INTO posts (post_id, title, content)
VALUES (101, 'Post 1','Lorem ipsum 1');

INSERT INTO posts (post_id, title, content)
VALUES (102, 'Post 2','Lorem ipsum 2');

INSERT INTO posts (post_id, title, content)
VALUES (103, 'Post 3','Lorem ipsum 3');


INSERT INTO posts (post_id, title, content)
VALUES (104, 'Post 4','Lorem ipsum 4');



SELECT *
FROM USER_TABLE 
LEFT JOIN posts 
ON USER_TABLE.id = posts.post_id;

