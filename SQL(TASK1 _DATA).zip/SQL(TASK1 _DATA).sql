
CREATE DATABASE userdb;

Use userdb;

CREATE TABLE User (
    id SERIAL PRIMARY KEY,
    username VARCHAR(25),
	password VARCHAR(25)
);     

SELECT * FROM User;

INSERT INTO User (id, username, password)
VALUES (1, 'Meghana','r123');

INSERT INTO User (id, username, password)
VALUES (2, 'Aditya','r12323');

INSERT INTO User (id, username, password)
VALUES (3, 'Pooja','r123456');
